// Paste me into the FileEdit configuration dialog

public class $CLASSNAME$ {
   public $RC$ $METHODNAME$($METHODPARMS$) {
		
   }


$BEGINCUT$
   $DEFAULTMAIN$
$ENDCUT$
}

$BEGINCUT$
$TESTCODE$
$ENDCUT$
